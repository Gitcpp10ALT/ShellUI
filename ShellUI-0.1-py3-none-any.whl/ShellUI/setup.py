from setuptools import setup, find_packages

setup(
    name="ShellUI",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "keyboard",  # Example dependency
        "os",  # Add required libraries here
	"time",
    ],
    description="A simple terminal UI interface",
    author="BB",
    author_email="bavanbo@mail.com",
)