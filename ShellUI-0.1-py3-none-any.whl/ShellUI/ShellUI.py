import keyboard
import os
import time

def menu_base(options, idx):
    os.system('cls' if os.name == 'nt' else 'clear')  # Clear the terminal for better visibility
    for i, option in enumerate(options):
        if i == idx:
            print(f"> {option} <")  # Highlight the selected option
        else:
            print(option)
def menu_confirm(options, idx, prompt):
    os.system('cls' if os.name == 'nt' else 'clear')  # Clear the terminal for better visibility
    print(f"|----{prompt}----|")
    for i, option in enumerate(options):
        if i == idx:
            print(f"> {option} <")  # Highlight the selected option
        else:
            print(option)

def draw_menu(options):
    idx = 0
    menu_base(options, idx)
    
    while True:
        key = keyboard.read_event().name  # Listen for key presses
        
        if key == "up":
            time.sleep(0.09)
            idx = max(0, idx - 1)  # Move up
        elif key == "down":
            time.sleep(0.09)
            idx = min(len(options) - 1, idx + 1)  # Move down
        elif key == "enter":
            selected_menu = options[idx]
            time.sleep(0.09)
            return selected_menu
        
        menu_base(options, idx)  # Update the menu display

def draw_checkboxes(options, selected, idx):
    os.system('cls' if os.name == 'nt' else 'clear')  # Clear the terminal for better visibility
    for i, option in enumerate(options):
        checkbox = "[x]" if selected[i] else "[ ]"  # Display checkbox state
        if i == idx:
            print(f"> {checkbox} {option} <")  # Highlight the selected option
        else:
            print(f"  {checkbox} {option}")

def checkbox_menu(options):
    idx = 0
    selected_cbx = [False] * len(options)  # Track checkbox states
    draw_checkboxes(options, selected_cbx, idx)
    
    while True:
        key = keyboard.read_key()  # Listen for key presses
        
        if key == "up":
            time.sleep(0.09)
            idx = max(0, idx - 1)  # Move up
        elif key == "down":
            time.sleep(0.09)
            idx = min(len(options) - 1, idx + 1)  # Move down
        elif key == "space":
            time.sleep(0.09)
            selected_cbx[idx] = not selected_cbx[idx]  # Toggle checkbox state
        elif key == "enter":
            time.sleep(0.09)
            return selected_cbx
        
        draw_checkboxes(options, selected_cbx, idx)

def dia_input(prompt):
    print(f"|----{prompt}----|")
    inputval = input()
    return inputval

def dia_confirm(options, prompt):
    idx = 0
    menu_confirm(options, idx, prompt)
    
    while True:
        key = keyboard.read_event().name  # Listen for key presses
        
        if key == "up":
            time.sleep(0.09)
            idx = max(0, idx - 1)  # Move up
        elif key == "down":
            time.sleep(0.09)
            idx = min(len(options) - 1, idx + 1)  # Move down
        elif key == "enter":
            selected_menu_confirm = options[idx]
            time.sleep(0.09)
            return selected_menu_confirm  # Return the selected option
        menu_confirm(options, idx, prompt)  # Update the menu display
